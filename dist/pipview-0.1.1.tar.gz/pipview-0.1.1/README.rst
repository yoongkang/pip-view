This is a command line tool that allows you to open up Python libraries
using your editor.

Ensure that the environment variable $EDITOR has been set.

Installation
--------
    pip install pipview


Usage:
--------

    pip-view [library-name]
