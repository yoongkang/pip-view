This is a command line tool that allows you to open up Python libraries
using your editor.

Ensure that the environment variable $EDITOR has been set.

Installation
--------
    $ git clone https://github.com/yoongkang/pip-view.git

    $ cd pip-view
    
    $ python setup.py install


Usage:
--------

    pip-view [library-name]
